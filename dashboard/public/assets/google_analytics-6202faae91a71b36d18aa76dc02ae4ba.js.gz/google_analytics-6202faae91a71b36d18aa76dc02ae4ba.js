/**
 * Google Analytics Code created by Alex Oberhauser
 */
var _gaq=_gaq||[];_gaq.push(["_setAccount","UA-30656610-1"]),_gaq.push(["_trackPageview"]),function(){var e=document.createElement("script");e.type="text/javascript",e.async=!0,e.src=("https:"==document.location.protocol?"https://ssl":"http://www")+".google-analytics.com/ga.js";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)}();